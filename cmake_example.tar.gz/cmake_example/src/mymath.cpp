#include "mymath.hpp"

int add(int i, int j) {
    return i + j;
}