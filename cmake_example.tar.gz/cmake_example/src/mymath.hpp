#pragma once

int add(int i, int j);