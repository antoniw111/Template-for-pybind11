# cmake_example
Minimalny przykład integracji pybind11 z setuptools i CMake.
